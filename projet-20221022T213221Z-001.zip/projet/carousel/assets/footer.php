<?php
echo ' <footer class="container">
    <p class="float-end"><a href="#">Retour</a></p>
  </footer>';
?>